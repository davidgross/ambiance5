====================================WELCOME=============================================================================================
Ambiance&Radiance Themes for XFCE/LXDE. Version 12.04 (Based on latest theme from Ubuntu 12.04) 
A refined and tested port of Ambiance/Radiance themes for the XFCE/LXDE desktops.
Brought to you by: The RAVEfinity Project, Jared Sot. (www.ravefinity.blogspot.com) , (Formally: www.iravefuzion.blogspot.com)

This Version (12.04) Requires: Gnome/Gtk 3.4 and Newer. EG. Ubuntu 12.04 and newer only... (Distros from April 2012+)

This version (12.04) WILL NOT WORK on Ubuntu 11.10 Gnome/GTK 3.2 or lower.
If you would like to use this theme on Ubuntu 11.04,11.10 Please download the other version of this theme, Version 11.10.3! at our site above.
----------------------------------------------------------------------------------------------------------------------------------------

****NOTE PLEASE SEE: MAKING THE XFCE AND LXDE PANELS DISPLAY CORRECTLY. (NEEDED STEP BELLOW)****

(!) This theme will not effect Ubuntu's Stock Ambiance & Radiance Themes so don't worry! it's totally separate!

This "port" is not by the offical Ambiance/Radiance team, If you like it then give them the credit, If you hate it, blame us! and submit a fix! :)
however we use the latest stable code from their theme modified only sligtly to work on the XFCE/LXDE desktops.

Ambiance&Radiance Theme for XFCE/LXDE (This is not by the offical Ambiance/Radiance team)
Now you can easily have the unified experience of Ambiance/Radiance themes on LXDE and Openbox desktops.
Includes both: Ambiance & Radiance GTK2&3 Widget and Window border themes.
* Build to work with GTK3! Other Xfce or LXDE themes that don't support GTK3 yet look like Win95(TM) when running gtk3 apps! This theme won't do that!
* Installs as a sperate theme from the main Ambiance/Radiance, for use with XFCE/LXDE only. (please use offical Ambiance/Radiance for Gnome/Unity)

Ambiance&Radiance Theme for XFCE/LXDE.  Aims to be a complete and accurate port of the Ambiance/Radiance Themes for XFCE/LXDE. We have made great strides to make sure it is accurate and complete. It usees the offical Ambiance/Radiance code modified only sligtly to work on XFCE/LXDE desktops. And *ports of* the offical window borders for XFCE (XFWM4) and LXDE (Openbox) in both Ambiance/Radiance flavors. We have updated and made small fixes to the window border themes as well as totally implemented the Radiance on top of XFCE (XFWM4) and LXDE (Openbox) (Not previously available). You will find this theme is probably the most complete package out there to easily have the unified experiacne of Ambiance/Radiance on the LXDE and Openbox since out of the box that theme doesn't really support such desktops.

Brought to you by(Based on):

RAVEfinity (C) 2011-2012+ RAVEfinty, (Jared Sot.) (www.ravefinity.blogspot.com)
We brought all the peices together, We applied and made ALOT of fixes , And we now mantain and devlop the XFCE, LXDE and Openbox Ambiance/Radiance themes. We have also updated the GTK theme to work on XFCE/LXDE. And made this a unified package.

(Based on stock Ambiance/Radiance, We modify as little as possible to make it work on XFCE/LXDE & Openbox.)
Ambiance/Radiance Themes Designed and created By: Kenneth Wimer, James Schriver, Andrea Cimitan (C) 2010-2011 GPL Canonicol LTD.

Primary (Debian/Ubuntu) Software packaging and autobuild launchpad scripts and other help By: Dr. Amr Osman

Lots of Patches, Fixes & Enhancements For Xfce,Lxde and Openbox Namely "Add Widget Fix" and "Overall" Panel Fix.
By: Benoit Thibaud (C) 2012 GPL 

(Originol Openbox Border Based On (Note: we now devlop and mantain this as separate updated "fork" that your useing.)
Ambiance Openbox (Window Borders) By: David Barr (C) 2010 GPL. (http://david.chalkskeletons.com/)*We use the originol and,then ported Radicane based on this.

(Originol XFCE Border Based On (Note: we now devlop and mantain this as separate updated "fork" that your useing.)
Ambiance for XFCE(Window Borders) By: p0ng (C) 2010 GPL  (http://www.p0ng.com.br)*We have applied fixes and ported Radicane based on this.

========================== QUICK NOTES=============================================================================================

This theme was built to be a independent package that allows you to use the Ambiance & Radiance Themes on XFCE/LXDE, It does this by being a seperate theme completely called Ambiance-XFCE/LXDE, Radiance-XFCE/LXDE. It does not motify your stock Ambiance & Radiance. We reccomend you use it on XFCE/LXDE only. And Use the offical Ambiance & Radiance Themes for Gnome and Unity.

Thats being said just install and activate it in XFCE or LXDE as follows (remember to select Ambiance-XFCE/LXDE, Radiance-XFCE/LXDE and not the stock version!)

(!) Always back up your data and use thease instructions at own risk! its not ours nor our contributors falt if anything goes wrong.
We have taken great strides to provide clear concise and safe instructions! But as always Do This at your own risk ! No Warranty!

======================How to Install/Use=========================================================================================
------------------------------------------------------------------------------------------------------------------------------------------------------------
(!) Due to permission issues in the GTK Theme System. You may not see the theme properly in root based (Sudo) applications you run from your normal user account if you install the theme in your home folder (/home/YourName/.Themes ) to Avoid/Fix this. Consider installing the Theme System Wide (See bellow) and it will work everywhere!
------------------------------------------------------------------------------------------------------------------------------------------------------------
Install The Theme. *System Wide* -The Recommended Method!
(Note: this Method requires Root or SUDO privileges)

(!) If you have, Gnome2,XFCE,LXDE,Openbox or Unity 2nd Gen Do this! 

Overview of what we need to do:
(To Intsall Ambiance&Radiance-Xfce-LXDE, You Simply Extract the complete package you just downloaded the "Ambiance&Radiance-XfceLXDE.tar.gz" (Folders and all)
to the themes folder for your entire system..."/usr/share/themes/")

Install The Ambiance&Radiance-XfceLXDE Theme:

1.) Open a terminal and type: sudo file-roller (Then type your password when asked)
-Fedora/Redhat Users Without sudo, type: "su -c file-roller" (Then type the root password)

4.) Now You will see the File Roller Archiver application...

Click "File -> Open" Then Browse for the package you just downloaded: "Ambiance&Radiance-XfceLXDE". Then click open.

5.) Once You've opened the "Ambiance&Radiance-XfceLXDE" Tar file, 

Select "Extract". Then Browse to the fallowing folder:"/usr/share/themes/" Then click ok!

6.)The Ambiance&Radiance-XfceLXDE Theme Should now be installed! Now all you must do is select the Ambiance-XfceLXDE or Radiance-XfceLXDE theme VIA your desktops theme manager!

Please Note: You may have to select both the GTK Widget Theme , And Metatcity , XFCEWM & Openbox Window themes separately depending on what desktop your using!

------------------------------------------------------------------------------------------------------------------------------------------------------------
(Install The Theme... *For Your User Account Only*) -

To install The Theme for *your user account only* Automatically, assuming you have the Gnome 2x Desktop or Mate Desktop. 
NOTE: GTK3 (Ubuntu 12.04) will not work this way.

1.) Right Click on the desktop

2.) Select Change Background 

3.) Click on the "Themes tab"

4.) Simply Drag The Entire Theme Package You Just Downloaded ("Ambiance&Radiance-XfceLXDE.tar.gz") Into The Theme Window.

5.) It Should Auto Install

(!) If it does not install or you are using Xfce,LXDE or Openbox,  you can try the method bellow (but we highly recommend *System Wide Method* see the top of this document)
----------------------------------------------------------------------------------------------------------------------------------------------------------- 
(Manually Install The Theme.  *For Your User Account Only*)
To install The Theme for *your user account only*, Fallow these steps, They should work on any GTK2&3 *nix desktop.

1.) Click to Open Up the package file you just downloaded... "Ambiance&Radiance-XfceLXDE.tar.gz"

2.) Once Open, Click the "Extract" Button... Then Browse to: /Home/YourUserName/.Themes

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory. 

3.) Extract the complete package "Ambiance&Radiance-XfceLXDE.tar.gz" file (Folders and all)
to the ".themes" folder in your home directory.

4.) Select it VIA your Theme Manager! see bellow.

(!) This will install the icon theme for the current user only , Evey user will have to do this on there own!, Thats why we recommend the system wide method
------------------------------------------------------------------------------------------------------------------------------------------------------------ 

-On XFCE Desktops Do this to use theme-


1.) Click On The "XFCE Menu".  (Should be On the far left of either the top or bottom of your desktop.)

2.) Click On The "Settings Menu"  Then --> "XFCE Settings Manager"

3.) Now Click The "Appearance" Category.

4.) Now Select Your Desired Version, Ambiance-XfceLXDE or Radiance-XfceLXDE theme from the List!, In the "Style" tab.

5.) Now Go back by clicking the  "<-- Overview" (Back Button)  And select the "Window Manager" Category

6.) Now Select Your Desired Version of Ambiance-XfceLXDE or Radiance-XfceLXDE theme from the List!, In the "Style" Tab Of the "Window Manager" Category.

7.) Once Done you may click Close ! :) 


(!) In case XFCE Settings Manager is not Installed (It really should be, because it's pretty cool), You can also get to the same locations above VIA Clicking:

 "XFCE Menu --> Settings Menu" --> "Appearance"      (then See Step 4)

 "XFCE Menu --> Settings Menu" --> "Window Manager"  (then See step 6)

(!) Note you may also want to enable the Ubuntu Mono Icon theme (Light or Drak depending on what there your useing) from the icon style tab.

Thats All!
-------------------------------------------------------------------------------------------------------------------------------------------------------------
-On LXDE Desktops Do this to use theme-

1.) Click On the "Start" Icon (The Circular Icon in the Taskbar/Panel in far left of your screen.) 

2.) Select The "Preferences Menu", Then --> "Customize Look and Feel" Menu Item

3.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In the: "Widget" Tab And Click Apply.

Lastly! To Select the Window Borders on LXDE...
4.) Select The "Preferences Menu", Then --> "Openbox Configuration Manager" Menu Item

5.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In The "Openbox Configuration Manager" Themes Tab.

!) Note you may also want to enable the Ubuntu Mono Icon theme (Light or Drak depending on what there your useing) from the icon style tab.

Thats All!

-------------------------------------------------------------------------------------------------------------------------------------------------------------
-On OpenBox Desktops Do This-

Openbox, out of the box does not have a GUI fronted option to switch your GTK-Theme and Icons.
However most prebuilt openbox desktops Such as CrunchBang(Openbox Edition), ETC will will include the lxappearance utility. If you don't have this utility you should install it via your package manager.

Once it is installed, You can launch it via the command line or run command dialog...

1.) Right click on your Openbox desktop and Find the "lxappearance" Application in your openbox menu. Or Open a terminal or run command prompt and type: lxappearance (and press  enter)

2.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In the: "Widget" Tab And Click Apply.

3.) Now Open your Openbox menu by right clicking and find the obconf (Openbox Configuration Manager) Application.

4.) Now Select Your Desired Version Of the Ambiance-XfceLXDE or Radiance-XfceLXDE theme From the List In The "Openbox Configuration Manager" Themes Tab. 

Thats All!
-------------------------------------------------------------------------------------------------------------------------------------------------------------

=============MAKING THE XFCE AND LXDE PANELS DISPLAY CORRECTLY. (NEEDED STEP)========================================================

Note for Xfce and LXDE users... Starting with theme version "11.10.3" and newer+

Due to their setup. Xfce and LXDE no longer have their panel background images applied automatically in the Theme it's self. We still support these desktops 100% as we did before but the panel background must now be set manually.

The reason for this change is Xfce and LXDE do not currently have fitting theme code options to use a "Panel.png" in the theme it's self for the panel without causing issues. Issues range from ugly unreadable segments or apps to major CPU USE from corruption. (Luckily the issues are contained and do not suck RAM just CPU until app with issue is closedoo. still this is unacceptable.) 

So It is NOW necessary for Ambiance and Radiance Xfce and LXDE users to set their panel background manually. The end result looks the same or better then before and avoids the mentioned issues.

So Heres how we set the panel background image... 
*REMEMBER* In doing it this way. Your panel will not change unless you change it! However it's very easy and safe to do! So before you change to another theme (Say down the line) make sure you reverse the changes made here. Or do the same for that theme (If it requires it)
---------------------------------------------------------------------------------------------------------------------------------------------------------

Activating the Ambiance or Radiance Panel Background in Xfce...

(!) Note that all Ambiance-ColorName themes use the same panel background. Same for the Radiance-ColorName themes.
so if you change to a different color you don't need to change the panel again unless your changing from Ambiance to Radiance (Or vise versa)

1.) Select and apply the Ambiance or Radiance Colors Xfce Theme of your choice (See howto guide on that if your unsure how.)  
-You should see the theme has taken effect BUT the panel does not look quite right yet! Lets fix that now.

2.) Right Click on the Xfce Panel. 

3.) Now on the pop-up dialog that appears select the "Panel" Submenu -> then select "Panel Preferences" Option.

3.) Now you will see a window that says "Panel" Click on the "Appearance" tab from this window.

4.) Now under the "Background" Section. Click on the "Style" drop-down menu and select "Background Image" from the drop down.  (To Reverse any of these changes all you must do change this "Style" option back to "None (use system default)"

5.) Now under the Section that reads "File" click the box that reads "None" or a filename if previously used.

6.) A File Browser Window Titled "Select A Panel Background" Will now appear. Now Simply browse to one of the fallowing directories.

A.)
If your using The Ambiance XfceLXDE Theme:
/usr/share/themes/Ambiance-XfceLXDE/apps/img/

If your using The Radiance XfceLXDE Theme:
/usr/share/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel.png" file

If you can't find the "/" or "usr" folders Try clicking the option on the side panel labeled filesystem (on the left-hand side panel). 
Now Browse to the folder "usr" then the folder "share" then the folder "themes" EG. /usr/share/themes/

B.)
If you installed the theme in your home directory (Not likely unless you did it yourself on purpose.) Then Browse to...

If your using The Ambiance XfceLXDE Theme:
/home/USERNAME/themes/Ambiance-XfceLXDE/apps/img/

If your using The Radiance XfceLXDE Theme:
/home/USERNAME/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel.png" file

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory. You can then press ctrl+h again to rehide it (For tidiness sake)

OR IF YOU USE A BIG PANEL(S):
(This can be applied to a big panel. You can use both small and big panels if you like! use the other file for smaller panels mentioned above and this file for big ones only)

If you have a larger panel repeat steps 1-5 on the large panel then browse to...

If your using a Ambiance Colors Theme:
/usr/share/themes/Ambiance-XfceLXDE/apps/img/

If your using a Radiance Colors Theme:
/usr/share/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel_big.png" file

If you can't find the "/" or "usr" folders Try clicking the option on the side panel labeled filesystem (on the left-hand side panel). 
Now Browse to the folder "usr" then the folder "share" then the folder "themes" EG. /usr/share/themes/

B.)
If you installed the theme in the Themes your home directory (Not likely unless you did it yourself on purpose.) Then Browse to...

If your using a Ambiance Colors Theme:
/home/USERNAME/themes/Ambiance-XfceLXDE/apps/img/

If your using a Radiance Colors Theme:
/home/USERNAME/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel_big.png" file

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory. You can then press ctrl+h again to rehide it (For tidiness sake)

Thats it!

Remember!: To change from Ambiance or Radiance panel background if needed. (depends on what theme you use at the time.)

Remember!: You will now need to adjust your panel manually (It will keep the selected background until changed by you.) You can revert it to it's previous state where it will auto adjust however this means you will have only very simple panel themes (EG.One Color) But if your changing themes that may be fine.

HOWTO REVERT THESE CHANGES:

1.) Right Click on the Xfce Panel. 

2.) Now on the pop-up dialog that appears select the "Panel" Submenu -> then select "Panel Preferences" Option.

3.) Now you will see a window that says "Panel" Click on the "Appearance" tab from this window.

4.) Now under the "Background" Section. Click on the "Style" drop-down menu and select "None (use system default)" from the drop down.

Now Your back to stock settings.

--------------------------------------------------------------------------------------------------------------------------------------------------------

Activating the Ambiance or Radiance Colors Panel Background in LXDE...


1.) Right click on the LXDE panel (The strip on the bottom or top of your desktop that holds your menu and clock)

2.) Select "Panel Settings" From the right click menu.

3.) You should see a window called "Panel Preferences" Click on the "Appearance tab"

4.) Once in the appearance tab. You will see a category called "Background" Change the selected (Or bubbled) option from "System theme" to "Image"

5.) Now click on the "Big square box with the folder icon" directly right of the "Image" Option. This allows you to browse to the desired image.

6.) You should see a window called "Select and image" In Ambiance & Radiance Colors you can browse to the fallowing paths...

7.) In the window called "Select and image" Click on "file-system" on the left-hand side. Now Browse to the folder "usr" then the folder "share" then the folder "themes"
EG. /usr/share/themes/


8.) Once in the folder path "/usr/share/themes/" Browse to  one of the fallowing the folders:

If your using The Ambiance XfceLXDE Theme:
/usr/share/themes/Ambiance-XfceLXDE/apps/img/panel.png 

If your using The Radiance XfceLXDE Theme:
/usr/share/themes/Radiance-XfceLXDE/apps/img/panel.png


Then finally click on the file "panel.png" and click open!

OR

If you installed the theme in your home directory (Not likely unless you did it yourself on purpose.) Then Browse to...

If your using The Ambiance XfceLXDE Theme:
/home/USERNAME/themes/Ambiance-XfceLXDE/apps/img/

If your using The Radiance XfceLXDE Theme:
/home/USERNAME/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel.png" file

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory. You can then press ctrl+h again to rehide it (For tidiness sake)


9.) You did it! now all you have to do is logout and log back in for the entire panel theme change to take effect.


OR IF YOU USE A BIG PANEL(S):
(This can be applied to a big panel. You can use both small and big panels if you like! use the other file for smaller panels mentioned above and this file for big ones only)

If you have a larger panel repeat steps 1-7 on the large panel then browse to...

If your using The Ambiance XfceLXDE Theme:
/usr/share/themes/Ambiance-XfceLXDE/apps/img/

If your using The Radiance XfceLXDE Theme:
/usr/share/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel_big.png" file

If you can't find the "/" or "usr" folders Try clicking the option on the side panel labeled filesystem (on the left-hand side panel). 
Now Browse to the folder "usr" then the folder "share" then the folder "themes" EG. /usr/share/themes/

B.)
If you installed the theme in the Themes your home directory (Not likely unless you did it yourself on purpose.) Then Browse to...

If your using The Ambiance XfceLXDE Theme:
/home/USERNAME/themes/Ambiance-XfceLXDE/apps/img/

If your using The Radiance XfceLXDE Theme:
/home/USERNAME/themes/Radiance-XfceLXDE/apps/img/

And Select the "panel_big.png" file

(!)To see the folder (it's a hidden one!) press ctrl+h in this file browser window to view hidden folders. the folder we want to install it in is ".themes" in your home directory. You can then press ctrl+h again to rehide it (For tidiness sake)

Remember!: To change from Ambiance or Radiance panel background if needed. (depends on what theme you use at the time.)

Remember!: You will now need to adjust your panel manually (It will keep the selected background until changed by you.)

HOWTO REVERT THESE CHANGES:

If you want to get the default LXDE look (Stock) back, just do this:


For the default LXDE look. (Note: that this is NOT the default on Lubuntu or other custom distros)

1.) Right click on the LXDE panel (The strip on the bottom or top of your desktop that holds your menu and clock)

2.) Select "Panel Settings" From the right click menu.

3.) You should see a window called "Panel Preferences" Click on the "Appearance tab"

4.) Once in the appearance tab. You will see a category called "Background" Change the selected (Or bubbled) option from "System theme" to "Image"

5.) Now click on the "Big square box with the folder icon" directly right of the "Image" Option. This allows you to browse to the desired image.

6.) You should see a window called "Select and image"

7.) In the window called "Select and image" Click on "file-system" on the left-hand side. Now Browse to the folder "usr" then the folder "share" then the folder "lxpanel"

8.) Once in the folder path "/usr/share/lxpanel/" click on the file "background.png" and click open!

(!) now logout and back in.


If you are using a different theme or distro that is not effected and want to revert back to it's default look just do this.

1.) Right click on the LXDE panel (The strip on the bottom or top of your desktop that holds your menu and clock)

2.) Select "Panel Settings" From the right click menu.

3.) You should see a window called "Panel Preferences" Click on the "Appearance tab"

4.) Once in the appearance tab. You will see a category called "Background" Change the selected (Or bubbled) option to "System theme"

---------------------------------------------------------------------------------------------------------------------------------------------------------
Thats All! - Written by Jared Sot. (Please forgive any spelling errors. It's a lot of work to  provide complete and up to date documentation. )
---------------------------------------------------------------------------------------------------------------------------------------------------------
